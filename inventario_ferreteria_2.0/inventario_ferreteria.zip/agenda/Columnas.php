	
	<?php
	

		include ('../conexion.php');
		$id_agencia=$_POST["idagen"];
	 
		
		
		$query =$base->prepare("select id_consultorio as id, nombre as title from tbl_consultorios  where id_agencia='".$id_agencia."'");
		$query->execute();
		if(!$query):			
			    echo 'Error al ejecutar la consulta';
		else:
 				//echo 'intentando obtener registros';
    			$results = $query->fetchAll(PDO::FETCH_ASSOC);
   				echo json_encode($results);
		endif;
	?>