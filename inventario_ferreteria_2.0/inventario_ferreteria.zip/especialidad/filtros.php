<h1 align="center">Especialidad<a href="registroFMR.php"><button class="btn btn-primary">Nuevo </button></a></h1>
<div class="wrapper">
<form  method="post" class="form-horizontal" role="form">
    <div class="panel panel-primary">       
        <div class="panel-footer">
        	<div class="form-group">

                 <div class="col-md-2">
                  <input type="button" name="des" id="des" value="Desactivados" class="btn btn-warning">
                </div>
            </div>
        </div>
     </div>
     </form>
</div>
