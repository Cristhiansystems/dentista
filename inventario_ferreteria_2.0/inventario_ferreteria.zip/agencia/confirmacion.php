


<?php
	include("../conexion.php");
?>


<html>

<head>
<meta charset="utf-8">
<title>Confirmacion de Cita</title>


</head>

<body >

	<h1>Clinica Dental All</h1>
	<h2>CONFIRMAR CITA</h2>




     
</body>

</html>