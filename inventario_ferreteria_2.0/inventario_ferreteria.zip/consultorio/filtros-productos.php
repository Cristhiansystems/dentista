<div class="form-horizontal">
        <div class="form-group">        
          <div class="col-sm-10">
           <a href="registroFMR.php">
            <button class="btn btn-primary">Nuevo </button>
          </a>
          </div>
        </div>
        <input type="hidden" name="tipo" id="tipo">
          <div class="form-inline">
              <div class="form-group col-sm-9" >
               
                  <input type="button" name="rep" id="rep" value="PDF" class="btn btn-secondary">
                  <input type="button" name="des" id="des" value="Desactivados" class="btn btn-warning">
             </div>

                 
          
              
                  <label for="busc">Buscar:</label> 
                  
                  <input class="form-control" type="text" name="buscar" id="buscar"  >
                 
              
               
           
            
                
          </div>
                
             
                
         
       

 </div>
        
         
        
