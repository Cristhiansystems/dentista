CREATE DATABASE IF NOT EXISTS `inventario_ferreteria`;

USE `inventario_ferreteria`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cuenta`;

CREATE TABLE `cuenta` (
  `id_cuenta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `costo` decimal(11,2) NOT NULL,
  `pagado` decimal(11,2) NOT NULL,
  `saldo` decimal(11,2) NOT NULL,
  `seguro` decimal(11,2) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_cuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4;

INSERT INTO `cuenta` VALUES (56,"2020-09-15","50.00","30.00","20.00","0.00",3,"activo"),
(57,"2020-09-15","50.00","0.00","50.00","0.00",3,"activo"),
(58,"2020-09-15","400.00","50.00","0.00","350.00",9,"activo"),
(59,"2020-09-15","50.00","10.00","40.00","0.00",9,"activo");


DROP TABLE IF EXISTS `detalle_tratamiento`;

CREATE TABLE `detalle_tratamiento` (
  `id_detalle_tratamiento` int(11) NOT NULL AUTO_INCREMENT,
  `precio_unitario` decimal(11,2) NOT NULL,
  `id_cuenta` int(11) NOT NULL,
  `id_tratamiento` int(11) NOT NULL,
  `id_pieza` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `id_pago` int(11) NOT NULL,
  `estado_pago` varchar(20) NOT NULL,
  `realizado` varchar(5) NOT NULL,
  `fecha_detalle` date NOT NULL,
  PRIMARY KEY (`id_detalle_tratamiento`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detalle_tratamiento` VALUES (97,"50.00",56,6,1,20,0,"Cuotas","si","2020-09-15"),
(98,"50.00",56,6,1,20,0,"Pagado","si","2020-09-15"),
(99,"50.00",57,6,1,20,0,"Debe","no","2020-09-15"),
(100,"350.00",58,7,4,20,0,"Seguro","si","2020-09-15"),
(101,"50.00",58,6,1,20,46,"Pagado","si","2020-09-15"),
(102,"50.00",59,6,1,20,0,"Cuotas","no","2020-09-15");


DROP TABLE IF EXISTS `especialidad`;

CREATE TABLE `especialidad` (
  `id_especialidad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_especialidad`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `especialidad` VALUES (1,"ortodoncia","activo"),
(2,"limpieza bucal","activo"),
(3,"Odontopediatria","activo");


DROP TABLE IF EXISTS `pago`;

CREATE TABLE `pago` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `costo` decimal(11,2) NOT NULL,
  `descuento` int(11) NOT NULL,
  `costo_total` decimal(11,2) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_cuenta` int(11) NOT NULL,
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pago` VALUES (43,"2020-09-15","10.00",0,"10.00",1,56),
(44,"2020-09-15","15.00",0,"15.00",1,56),
(45,"2020-09-15","5.00",0,"5.00",1,56),
(46,"2020-09-15","50.00",0,"50.00",1,58),
(47,"2020-09-15","10.00",0,"10.00",1,59);


DROP TABLE IF EXISTS `pieza`;

CREATE TABLE `pieza` (
  `id_pieza` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `pieza` varchar(5) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pieza`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pieza` VALUES (1,"molar",1,"activo"),
(2,"muela",11,"activo"),
(3,"muela ",12,"activo"),
(4,"Premolar",71,"activo");


DROP TABLE IF EXISTS `tbl_agencias`;

CREATE TABLE `tbl_agencias` (
  `id_agencia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `estado` varchar(15) NOT NULL,
  PRIMARY KEY (`id_agencia`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_agencias` VALUES (1,"Centro Calacoto","Calle 21","activo"),
(2,"Torrez Mall","Plaza Isabel La Catolica","activo"),
(3,"Prado","centro","activo"),
(4,"Particular","","activo"),
(5,"Agencia 2","Zona Sur 1","activo");


DROP TABLE IF EXISTS `tbl_aseguradoras`;

CREATE TABLE `tbl_aseguradoras` (
  `id_aseguradora` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(15) NOT NULL,
  PRIMARY KEY (`id_aseguradora`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_aseguradoras` VALUES (1,"San Cristobal","activo"),
(2,"Particular 2","activo"),
(3,"Santa","activo"),
(4,"particula 3","desactivo"),
(5,"Particular","activo");


DROP TABLE IF EXISTS `tbl_citas`;

CREATE TABLE `tbl_citas` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `estado` varchar(15) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `id_consultorio` int(11) NOT NULL,
  PRIMARY KEY (`id_cita`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_citas` VALUES (1,"2020-08-25","10:00:00","11:00:00","Anulado",1,13,3,1),
(2,"2020-08-25","09:00:00","10:00:00","Cumplido",1,13,1,2),
(3,"2020-08-25","10:00:00","11:00:00","Cancelado",2,13,1,1),
(4,"2020-08-25","10:00:00","11:00:00","Confirmado",1,13,1,1),
(5,"2020-08-25","10:00:00","11:00:00","Confirmado",3,13,3,1),
(6,"2020-08-25","11:00:00","12:00:00","Anulado",3,13,1,2),
(7,"2020-08-25","10:00:00","11:00:00","Reagendado",2,13,1,1),
(8,"2020-08-25","10:00:00","11:00:00","Reagendado",2,13,1,1),
(9,"2020-08-25","11:30:00","12:30:00","Anulado",3,13,1,1),
(10,"2020-08-25","11:30:00","12:30:00","Confirmado",3,13,1,1),
(11,"2020-08-26","09:30:00","10:30:00","Reagendado",3,13,1,1),
(12,"2020-09-04","08:30:00","10:00:00","Registrado",1,3,1,2),
(13,"2020-09-04","09:00:00","10:00:00","Anulado",5,19,3,3),
(14,"2020-09-05","09:00:00","10:30:00","Confirmado",3,3,1,3),
(15,"2020-09-05","11:30:00","13:00:00","Registrado",1,3,3,3),
(16,"2020-09-06","09:30:00","11:00:00","Registrado",1,3,3,3),
(17,"2020-09-08","09:30:00","10:30:00","Confirmado",1,3,3,3),
(18,"2020-09-09","08:30:00","09:30:00","Cancelado",3,3,3,2),
(19,"2020-09-10","09:30:00","11:00:00","Registrado",3,3,3,2),
(20,"2020-09-10","09:00:00","10:30:00","Registrado",3,3,3,4),
(21,"2020-09-10","09:30:00","10:30:00","Registrado",3,3,3,4),
(22,"2020-09-10","09:00:00","10:00:00","Registrado",3,3,1,4),
(23,"2020-09-10","09:30:00","10:30:00","Registrado",3,3,1,4),
(24,"2020-09-10","09:30:00","11:00:00","Registrado",3,3,3,4),
(25,"2020-09-10","09:00:00","10:00:00","Registrado",5,13,3,3),
(26,"2020-09-10","08:30:00","10:00:00","Pendiente",5,3,1,3),
(27,"2020-09-10","18:00:00","19:00:00","Registrado",4,3,3,3),
(28,"2020-09-10","19:30:00","20:30:00","Registrado",4,3,3,4),
(29,"2020-09-10","14:00:00","15:30:00","Pendiente",3,0,1,5),
(30,"2020-09-10","11:00:00","13:00:00","Registrado",3,0,3,1),
(31,"2020-09-10","12:00:00","14:00:00","Registrado",3,0,1,1),
(32,"2020-09-10","11:30:00","13:00:00","Registrado",3,3,1,1),
(33,"2020-09-10","11:00:00","12:00:00","Registrado",3,3,1,2),
(34,"2020-09-10","11:30:00","12:30:00","Registrado",3,3,1,3),
(35,"2020-09-10","13:00:00","14:00:00","Confirmado",4,3,1,4),
(36,"2020-09-10","09:30:00","11:00:00","Registrado",3,3,1,5),
(37,"2020-09-10","13:30:00","14:30:00","Registrado",2,17,1,2),
(38,"2020-09-13","09:00:00","10:00:00","Confirmado",4,3,20,2),
(39,"2020-09-15","09:00:00","10:00:00","Confirmado",3,3,20,2);


DROP TABLE IF EXISTS `tbl_consultorios`;

CREATE TABLE `tbl_consultorios` (
  `id_consultorio` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(15) NOT NULL,
  `id_agencia` int(11) NOT NULL,
  PRIMARY KEY (`id_consultorio`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_consultorios` VALUES (1,"Consultorio 1","desactivo",1),
(2,"Consultorio 2","activo",1),
(3,"Consultorio 1","activo",1),
(4,"consultorio 31","activo",1),
(5,"Consultorio 4","activo",1),
(6,"Consultorio 5","activo",2);


DROP TABLE IF EXISTS `tbl_cuotas`;

CREATE TABLE `tbl_cuotas` (
  `id_cuota` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `monto` double NOT NULL,
  `estado` varchar(20) NOT NULL,
  `id_cuenta` int(11) NOT NULL,
  `id_pago` int(11) NOT NULL,
  PRIMARY KEY (`id_cuota`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_cuotas` VALUES (28,1,"2020-09-15",10,"Cancelado",56,43),
(29,2,"2020-09-15",15,"Cancelado",56,44),
(30,3,"2020-09-15",5,"Cancelado",56,45),
(31,4,"0000-00-00",0,"Pendiente",56,0),
(32,5,"0000-00-00",0,"Pendiente",56,0),
(33,1,"2020-09-15",10,"Cancelado",59,47),
(34,2,"0000-00-00",0,"Pendiente",59,0),
(35,3,"0000-00-00",0,"Pendiente",59,0),
(36,4,"0000-00-00",0,"Pendiente",59,0),
(37,5,"0000-00-00",0,"Pendiente",59,0),
(38,6,"0000-00-00",0,"Pendiente",59,0),
(39,7,"0000-00-00",0,"Pendiente",59,0),
(40,8,"0000-00-00",0,"Pendiente",59,0),
(41,9,"0000-00-00",0,"Pendiente",59,0),
(42,10,"0000-00-00",0,"Pendiente",59,0),
(43,11,"0000-00-00",0,"Pendiente",59,0),
(44,12,"0000-00-00",0,"Pendiente",59,0),
(45,13,"0000-00-00",0,"Pendiente",59,0),
(46,14,"0000-00-00",0,"Pendiente",59,0),
(47,15,"0000-00-00",0,"Pendiente",59,0),
(48,16,"0000-00-00",0,"Pendiente",59,0),
(49,17,"0000-00-00",0,"Pendiente",59,0),
(50,18,"0000-00-00",0,"Pendiente",59,0);


DROP TABLE IF EXISTS `tbl_empleados`;

CREATE TABLE `tbl_empleados` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellido_paterno` varchar(20) NOT NULL,
  `apellido_materno` varchar(20) NOT NULL,
  `alias` varchar(5) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `ci` varchar(13) NOT NULL,
  `direccion` varchar(70) NOT NULL,
  `foto` varchar(40) NOT NULL,
  `celular` int(12) NOT NULL,
  `tipo_empleado` varchar(15) NOT NULL,
  `login` varchar(20) NOT NULL,
  `clave` varchar(20) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_empleados` VALUES (1,"Cristhian","Callizaya","Averanga","Dr.","1995-01-25",11103258,"Villa exaltacion primera seccion","imagenes/420823.jpg",70503313,"Medico","","","activo"),
(3,"Maciel","Zegarra","Atena","sasa","1995-08-15",6828327,"dhkahsa","imagenes/871351.png",70777777,"Asistente","admin","admin","activo"),
(13,"carlos","la","hhkh","we","1985-05-28",66797,"hkhk","imagenes/save_children.gif",79879846,"Asistente","","","activo"),
(14,"Marcos","Calibre","masas","hoaih","1995-05-21",23232,"hksds","imagenes/venta_productos.png",73572764,"Administrativo","Marcos","","activo"),
(15,"Lucas","Petros","hkhka","hkabs","1986-08-25",6483473,"sjlndsj","imagenes/image010.jpg",7927392,"Administrativo","","","activo"),
(16,"bkhaskhd","hkah","hakshk","hkdaa","1995-09-25",8885,"hkdbkds","imagenes/rojo.jpg",9279273,"Administrativo","","","activo"),
(17,"Mario","Gonzales","Peña","WAjal","1995-05-25",48948498,"la peña","imagenes/504835.jpg",77493443,"Asistente","Mario",123,"activo"),
(18,"Julian","Perez","Salva","was","1995-05-15",464644486,"mansjas","imagenes/121262.jpg",79494949,"Administrativo","","","activo"),
(19,"Charles","Da Silva","Peña","CHAL","1995-05-25",488484,"Villa","imagenes/163181.jpg",7848446,"Asistente","Charles",12345678,"activo"),
(20,"Mariel","Peñaloza","Saavedra","Dra.","1995-02-05",58658769,"dreccion","imagenes/86427.jpg",7998985,"Medico","","","activo"),
(21,"Carlos","Marin","Peña","PAC-C","1995-01-15",11105023,"Villa Copabana calle 4 nro 4","imagenes/243444.jpg",78554852,"Asistente","Carlos","Carlos","activo");


DROP TABLE IF EXISTS `tbl_pacientes`;

CREATE TABLE `tbl_pacientes` (
  `id_paciente` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_paciente` varchar(30) NOT NULL,
  `ci` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido_paterno` varchar(30) NOT NULL,
  `apellido_materno` varchar(30) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `celular` varchar(10) NOT NULL,
  `antecedente_patologico` varchar(60) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fecha_primera_visita` date NOT NULL,
  `estado` varchar(15) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `id_aseguradora` int(11) NOT NULL,
  PRIMARY KEY (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_pacientes` VALUES (1,"B111",51515,"Cristhian","Callizaya","Averanga","1995-08-12",70503313,"patoljvvvvvvkhygkh","gjhj","2020-08-18","activo",1,1),
(2,"P0001",1515,"Carlos","Peña","Larrea","1995-05-15",78542585,"lask","carlos@hotmail.com","2020-05-15","activo",1,1),
(3,"L0001",1516,"maria","lopez","abrego","1995-05-15",78586616,"ninguna","hcgch","2020-08-25","activo",3,1),
(4,"M0001",16165,"Carlos","Magno","","2020-08-12",7379232,"cnkajcna","bakcakc","2020-08-31","activo",1,2),
(5,"L0002",161651,"Mar","loza","","1999-08-15",749232,"jhdkasa","jkda","2020-09-15","activo",3,2),
(6,"L0003",152546,"Pepito ","Laza","Lora","2011-09-22",49849494,"ninguna","bapliacscsac","0000-00-00","activo",1,0),
(7,"L0004",381031,"Pepito","Lazo","Pol","1995-02-15",73928323,"abdadnas","bolivar","1995-05-15","activo",1,0),
(8,"C0002",0,"cris","cal","vvjh","2020-09-11",87498494,"ibiibkbjb","bolivar_baaas","1995-02-15","activo",1,5),
(9,"E0001",11105963,"Maria","Escobar","Escobar","1996-05-15",75256845,"Ninguno","maria@hotmail.com","2020-09-15","activo",20,5);


DROP TABLE IF EXISTS `tbl_urls`;

CREATE TABLE `tbl_urls` (
  `slug` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(620) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `hits` bigint(20) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Used for the URL shortener';

INSERT INTO `tbl_urls` VALUES ("a","https://github.com/mathiasbynens/php-url-shortener","2020-09-10 20:43:55",2),
("b","","2020-09-10 20:59:34",1065),
("c","http://www.casaita.com/cdsd.php","2020-09-10 21:02:41",1),
("d","http://www.dentall.com/agenda/confirmacion.php?id=4","2020-09-10 23:36:44",0),
("e","http://www.google.com","2020-09-11 01:03:45",2),
("f","http://www.casita.com","2020-09-11 01:04:37",0),
("g","http://www.csds.com","2020-09-11 01:04:56",0),
("h","http://www.csddsds.com","2020-09-11 01:05:04",0),
("i","http://www.csddkdjsdlsn.com","2020-09-11 01:05:11",0),
("j","http://www.csddkybhkbhkbdjsdlsn.com","2020-09-11 01:05:47",0),
("k","http://www.body.com","2020-09-11 17:18:31",1),
("l","http://localhost:8080/inventario_ferreteria/agenda/confirmacion.php?id=37","2020-09-11 18:43:41",0),
("m","http://localhost:8080/inventario_ferreteria/agenda/confirmacion.php?id=35","2020-09-12 01:34:17",10),
("n","http://localhost:8080/inventario_ferreteria/agenda/confirmacion.php?id=36","2020-09-12 02:02:13",7),
("o","http://localhost:8080/inventario_ferreteria/agenda/confirmacion.php?id=38","2020-09-15 10:29:37",0);


DROP TABLE IF EXISTS `tbl_usuarios`;

CREATE TABLE `tbl_usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_usuario` varchar(20) NOT NULL,
  `registro` date NOT NULL,
  `menu_mantenimiento` tinyint(1) NOT NULL,
  `menu_grupo_dental` tinyint(1) NOT NULL,
  `menu_citas` tinyint(1) NOT NULL,
  `menu_caja` tinyint(1) NOT NULL,
  `menu_procesos_dentales` tinyint(1) NOT NULL,
  `menu_consultas` tinyint(1) NOT NULL,
  `menu_seguridad` tinyint(1) NOT NULL,
  `id_agencia` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `estado` varchar(15) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_usuarios` VALUES (1,"Empleado","2020-09-03",1,1,1,1,1,1,1,1,3,"activo"),
(2,"Administrador","2020-09-03",1,1,0,1,1,1,1,3,17,"activo"),
(3,"Empleado","2020-09-10",1,1,1,0,1,1,0,2,3,"activo"),
(4,"Empleado","2020-09-15",1,0,1,1,1,1,0,5,21,"activo");


DROP TABLE IF EXISTS `tipo_producto`;

CREATE TABLE `tipo_producto` (
  `id_tipo_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `estado` varchar(30) NOT NULL,
  PRIMARY KEY (`id_tipo_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tipo_producto` VALUES (1,"gaseosas","activo");


DROP TABLE IF EXISTS `tratamiento`;

CREATE TABLE `tratamiento` (
  `id_tratamiento` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(11,2) NOT NULL,
  `seguro` varchar(5) NOT NULL,
  `id_especialidad` int(11) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_tratamiento`),
  KEY `id_especialidad` (`id_especialidad`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tratamiento` VALUES (1,"tr001","tratamiento1","13.50","No",1,"activo"),
(2,"tr002","tratamiento2","20.00","No",2,"activo"),
(3,"tra3","ligas","0.00","Si",2,"activo"),
(4,"t4","tratamiento4","34.80","Si",2,"activo"),
(5,"hkaas","Bucal","30.00","Si",2,"activo"),
(6,"tra5","Limpia Bocas","50.00","No",2,"activo"),
(7,"P","Pulpotomia","350.00","Si",3,"activo");


SET foreign_key_checks = 1;
